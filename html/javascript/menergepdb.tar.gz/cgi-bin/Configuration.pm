package Configuration;

our $JAVASCRIPT_URL = "http://bioinfo-test.ird.fr:84";
our $HTML_DIR = "/var/www/html";

return 1; # package return
